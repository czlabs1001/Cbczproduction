<?php defined('ABSPATH') || exit;

/**
 * Plugin Name: SPay WooCommerce
 * Version:     1.0.3
 * Plugin URI:  https://solpay-woocommerce.beycanpress.com/
 * Description: Plugin for WooCommerce to receive payments via the Solana network with cryptocurrency wallet
 * Author: BeycanPress
 * Author URI:  https://www.beycanpress.com
 * License:     GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.tr.html
 * Text Domain: solpay
 * Domain Path: /languages
 * Tags: SolPay, Cryptocurrency, WooCommerce, WordPress, Phantom, Sollet, Slope, Solflare, Torus, Bitcoin, Solana, Payment, Plugin, Gateway, Blockchain
 * Requires at least: 5.0
 * Tested up to: 6.0
 * Requires PHP: 7.4
*/

require __DIR__ . '/vendor/autoload.php';
new \BeycanPress\SolPay\WooCommerce\Loader(__FILE__);